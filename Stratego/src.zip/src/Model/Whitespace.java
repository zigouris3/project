package Model;

import java.awt.*;

public class Whitespace extends Piece{

    public Whitespace(String name,  int x, int y, Color team) {
        super("Whitespace", x, y, 0, Color.white);
    }
}
