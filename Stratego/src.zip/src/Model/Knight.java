package Model;

import java.awt.*;

public class Knight extends MoveablePiece {
    public Knight(String name, int x, int y, Color team) {
        super("Knight", x, y, 8, team);
    }
}
