package Model;

import java.awt.*;

public class Elf extends MoveablePiece {
    public Elf(String name, int x, int y, Color team) {
        super("Elf", x, y, 4, team);
    }
}
