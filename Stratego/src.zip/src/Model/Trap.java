package Model;

import java.awt.*;

public class Trap extends ImmovablePiece {
    public Trap(String name,  int x, int y, Color team) {
        super("Trap", x, y, 20, team);
    }
}
