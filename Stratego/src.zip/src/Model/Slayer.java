package Model;

import java.awt.*;

public class Slayer extends SpecialMoveablePiece {

    public Slayer(String name,  int x, int y, Color team) {
        super("Slayer",  x, y, 1, team);
    }

}
