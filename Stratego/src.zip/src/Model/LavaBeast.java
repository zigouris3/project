package Model;

import java.awt.*;

public class LavaBeast extends MoveablePiece {
    public LavaBeast(String name, int x, int y, Color team) {
        super("LavaBeast", x, y, 5, team);
    }
}
