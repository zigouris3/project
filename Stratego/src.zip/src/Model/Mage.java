package Model;

import java.awt.*;

public class Mage extends MoveablePiece {
    public Mage(String name,  int x, int y, Color team) {
        super("Mage",  x, y, 9, team);
    }
}
