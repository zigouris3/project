package Model;

import java.awt.*;

public class BeastRider extends MoveablePiece {
    public BeastRider(String name, int x, int y, Color team) {
        super("BeastRider", x, y, 7, team);
    }
}
