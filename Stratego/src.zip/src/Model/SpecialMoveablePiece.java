package Model;

import java.awt.*;

public abstract class SpecialMoveablePiece extends MoveablePiece {

    protected SpecialMoveablePiece(String name, int x, int y, int power, Color team) {
        super(name, x, y, power, team);
    }

}
