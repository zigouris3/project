package Model;

import java.awt.*;

public class Dragon extends MoveablePiece {
    public Dragon(String name, int x, int y, Color team) {
        super("Dragon", x, y, 10, team);
    }
}
