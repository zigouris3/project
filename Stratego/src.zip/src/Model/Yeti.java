package Model;

import java.awt.*;

public class Yeti extends MoveablePiece{
    public Yeti(String name,  int x, int y, Color team) {
        super("Yeti", x, y, 5, team);
    }
}
