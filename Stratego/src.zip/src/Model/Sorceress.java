package Model;

import java.awt.*;

public class Sorceress extends MoveablePiece {
    public Sorceress(String name,  int x, int y,  Color team) {
        super("Sorceress",  x, y, 6, team);
    }
}
